import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    # choose your yaml file
    model = YOLO('runs/train/new-400/exp-nwd-mpdiou-mlca-84.6/weights/best.pt')
    model.info(detailed=True)
    model.profile(imgsz=[640, 640])
    model.fuse()